<?php
// Text
$_['text_speedy_max_packages']               = 'Maximum number of products for package';
$_['text_speedy_package_dimentions']         = 'Package size in cm.';

// Column
$_['column_speedy_XS']                       = 'XS <br> (50 x 35 x 4,5)';
$_['column_speedy_S']                        = 'S <br> (60 x 35 x 11)';
$_['column_speedy_M']                        = 'M <br> (60 x 35 x 19)';
$_['column_speedy_L']                        = 'L <br> (60 x 35 x 37)';
$_['column_speedy_XL']                       = 'XL <br> (60 x 60 x 60)';

// Entry
$_['entry_speedy_quantity_dimensions']       = 'Speedy POST - Maximum number of units of product filling the package';