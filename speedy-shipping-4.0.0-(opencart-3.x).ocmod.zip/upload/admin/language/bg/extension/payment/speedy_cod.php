<?php
// Heading
$_['heading_title']      = 'Спиди наложен платеж';

// Text
$_['text_payment']       = 'Плащане';
$_['text_success']       = 'Успешно променихте параметрите на Спиди наложен платеж!';
$_['text_speedy_cod']    = '<a onclick="window.open(\'http://www.speedy.bg/?lang=bg\');"><img src="view/image/payment/speedy.png" alt="Спиди" title="Спиди" style="border: 1px solid #EEEEEE;" /></a>';
$_['text_edit']          = 'Редактиране на Спиди наложен платеж';

// Entry
$_['entry_order_status'] = 'Статус на поръчката:';
$_['entry_geo_zone']     = 'Гео зона:';
$_['entry_status']       = 'Статус:';
$_['entry_sort_order']   = 'Поредна позиция в колоната:';

// Error
$_['error_permission']   = 'Внимание: Нямате права да променяте параметрите на Спиди наложен платеж!';