<?php
// Text
$_['text_title'] = 'Speedy Cash On Delivery';