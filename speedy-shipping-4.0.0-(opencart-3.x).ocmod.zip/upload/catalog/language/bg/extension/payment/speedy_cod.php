<?php
// Text
$_['text_title'] = 'Спиди наложен платеж';