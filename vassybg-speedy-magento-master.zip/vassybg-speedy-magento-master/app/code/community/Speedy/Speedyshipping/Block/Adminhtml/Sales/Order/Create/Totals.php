<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Totals
 *
 * @author killer
 */
class Speedy_Speedyshipping_Block_Adminhtml_Sales_Order_Create_Totals extends Mage_Adminhtml_Block_Sales_Order_Create_Totals {

    //put your code here

    function __construct() {
       // $this->setTemplate('speedy_speedyshipping/sales/order/create/totals.phtml');
        parent::__construct();
        
        
    }

}

?>
