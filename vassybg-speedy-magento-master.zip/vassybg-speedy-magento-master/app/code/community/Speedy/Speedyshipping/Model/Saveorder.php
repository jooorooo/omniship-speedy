<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Speedy_SpeedyShipping_Model_Saveorder
 *
 * @author killer
 */
class Speedy_Speedyshipping_Model_Saveorder extends Mage_Core_Model_Abstract{
    //put your code here
    
    protected function _construct() {
        $this->_init('speedyshippingmodule/saveorder');
    }
}

?>
