<?php

require_once dirname(__FILE__).DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'EPSInterface.class.php';

/**
 * Speedy SOAP EPS ver01 Service Interface Implementation
 */
class EPSSOAPInterfaceImpl extends SoapClient implements EPSInterface {

    /**
     * Speedy SOAP WSDL version 01 URL
     * @var string
     */
    const SPEEDY_SOAP_WSDL_V01_URL = 'https://www.speedy.bg/eps/main01.wsdl';

    /**
     * Constructs new instance of SOAP service
     * @param string $wsdlURL
     * @param options[optional]
     */
    function __construct($wsdlURL=self::SPEEDY_SOAP_WSDL_V01_URL, $options=null) {
        if (is_null($options)) {
            parent::SoapClient($wsdlURL);
        } else {
            parent::SoapClient($wsdlURL, $options);
        }
        //   echo('<BR>Connected to '.$wsdlURL);
    }

    /**
     * @see EPSInterface::login()
     */
    public function login($username, $password) {
        try {
            $loginSdtClass = new stdClass();
            $loginSdtClass->username = $username;
            $loginSdtClass->password = $password;
            $response = parent::login($loginSdtClass);
            if (isset($response->return)) {
                $resultLogin = new ResultLogin($response->return);
            } else {
                $resultLogin = null;
            }
            return $resultLogin;
        } catch (SoapFault $sf) {
            throw new ServerException($sf);
        }
    }

    /**
     * @see EPSInterface::isSessionActive()
     */
    public function isSessionActive($sessionId, $refreshSession) {
        try {
            $isSessionActiveSdtClass = new stdClass();
            $isSessionActiveSdtClass->sessionId      = $sessionId;
            $isSessionActiveSdtClass->refreshSession = $refreshSession;
            $response = parent::isSessionActive($isSessionActiveSdtClass);
            if (isset($response->return)) {
                $isSessionActiveFlag = $response->return;
            } else {
                $isSessionActiveFlag = false;
            }
            return $isSessionActiveFlag;
        } catch (SoapFault $sf) {
            throw new ServerException($sf);
        }
    }

    /**
     * @see EPSInterface::listServices()
     */
    public function listServices($sessionId, $date) {
        try {
            $listServicesStdObject = new stdClass();
            $listServicesStdObject->sessionId = $sessionId;
            $listServicesStdObject->date      = $date;
            $response = parent::listServices($listServicesStdObject);
            $arrListServices = array();
            if (isset($response->return)) {
                $arrStdServices = $response->return;
                if (is_array($arrStdServices)) {
                    for($i = 0; $i < count($arrStdServices); $i++) {
                        $arrListServices[$i] = new ResultCourierService($arrStdServices[$i]);
                    }
                } else {
                    $arrListServices[0] = new ResultCourierService($arrStdServices);
                }
            }
            return $arrListServices;
        } catch (SoapFault $sf) {
            throw new ServerException($sf);
        }
    }

    /**
     * @see EPSInterface::listServicesForSites()
     */
    public function listServicesForSites($sessionId, $date, $senderSiteId, $receiverSiteId) {
        try {
            $listServicesForSitesStdObject = new stdClass();
            $listServicesForSitesStdObject->sessionId      = $sessionId;
            $listServicesForSitesStdObject->date           = $date;
            $listServicesForSitesStdObject->senderSiteId   = $senderSiteId;
            $listServicesForSitesStdObject->receiverSiteId = $receiverSiteId;
            $response = parent::listServicesForSites($listServicesForSitesStdObject);
            $arrServicesForSitesStdObject = array();
            if (isset($response->return)) {
                $arrStdServicesForSites = $response->return;
                if (is_array($arrStdServicesForSites)) {
                    for($i = 0; $i < count($arrStdServicesForSites); $i++) {
                        $arrServicesForSitesStdObject[$i] = new ResultCourierServiceExt($arrStdServicesForSites[$i]);
                    }
                } else {
                    $arrServicesForSitesStdObject[0] = new ResultCourierServiceExt($arrStdServicesForSites);
                }
            }
            return $arrServicesForSitesStdObject;
        } catch (SoapFault $sf) {
            throw new ServerException($sf);
        }
    }

    /**
     * @see EPSInterface::listSites()
     */
    public function listSites($sessionId, $type, $name) {
        try {
            $listSitesStdObject = new stdClass();
            $listSitesStdObject->sessionId = $sessionId;
            $listSitesStdObject->type      = $type;
            $listSitesStdObject->name      = $name;
            $response = parent::listSites($listSitesStdObject);
            $arrListSites = array();
            if (isset($response->return)) {
                $arrStdSites = $response->return;
                if (is_array($arrStdSites)) {
                    for($i = 0; $i < count($arrStdSites); $i++) {
                        $arrListSites[$i] = new ResultSite($arrStdSites[$i]);
                    }
                } else {
                    $arrListSites[0] = new ResultSite($arrStdSites);
                }
            }
            return $arrListSites;
        } catch (SoapFault $sf) {
            throw new ServerException($sf);
        }
    }

    /**
     * @see EPSInterface::listSites()
     */
    public function listSitesEx($sessionId, $paramFilterSite) {
        try {
            $listSitesExStdObject = new stdClass();
            $listSitesExStdObject->sessionId = $sessionId;
            $listSitesExStdObject->filter    = $paramFilterSite->toStdClass();
            $response = parent::listSitesEx($listSitesExStdObject);
            $arrListSitesEx = array();
            if (isset($response->return)) {
                $arrStdSitesEx = $response->return;
                if (is_array($arrStdSitesEx)) {
                    for($i = 0; $i < count($arrStdSitesEx); $i++) {
                        $arrListSitesEx[$i] = new ResultSiteEx($arrStdSitesEx[$i]);
                    }
                } else {
                    $arrListSitesEx[0] = new ResultSiteEx($arrStdSitesEx);
                }
            }
            return $arrListSitesEx;
        } catch (SoapFault $sf) {
            throw new ServerException($sf);
        }
    }

    /**
     * @see EPSInterface::getWeightInterval()
     */
    public function getWeightInterval($sessionId, $serviceTypeId, $senderSiteId, $receiverSiteId, $date, $documents) {
        try {
            $getWeightIntervalStdObject = new stdClass();
            $getWeightIntervalStdObject->sessionId      = $sessionId;
            $getWeightIntervalStdObject->serviceTypeId  = $serviceTypeId;
            $getWeightIntervalStdObject->senderSiteId   = $senderSiteId;
            $getWeightIntervalStdObject->receiverSiteId = $receiverSiteId;
            $getWeightIntervalStdObject->date           = $date;
            $getWeightIntervalStdObject->documents      = $documents;
            $response = parent::getWeightInterval($getWeightIntervalStdObject);
            if (isset($response->return)) {
                $resultMinMaxReal = new ResultMinMaxReal($response->return);
            } else {
                $resultMinMaxReal = null;
            }
            return $resultMinMaxReal;
        } catch (SoapFault $sf) {
            throw new ServerException($sf);
        }
    }

    /**
     * @see EPSInterface::getAddressNomenclature()
     */
    public function getAddressNomenclature($sessionId, $nomenType) {
        try {
            $getAddressNomenclatureStdObject = new stdClass();
            $getAddressNomenclatureStdObject->sessionId = $sessionId;
            $getAddressNomenclatureStdObject->nomenType = $nomenType;
            $response = parent::getAddressNomenclature($getAddressNomenclatureStdObject);
            if (isset($response->return)) {
                $getAddressNomenclature = $response->return;
            } else {
                $getAddressNomenclature = null;
            }
            return $getAddressNomenclature;
        } catch (SoapFault $sf) {
            throw new ServerException($sf);
        }
    }

    /**
     * @see EPSInterface::listAllSites()
     */
    public function listAllSites($sessionId) {
        try {
            $listAllSitesStdObject = new stdClass();
            $listAllSitesStdObject->sessionId = $sessionId;
            $response = parent::listAllSites($listAllSitesStdObject);
            $arrListAllSites = array();
            if (isset($response->return)) {
                $arrStdAllSites = $response->return;
                if (is_array($arrStdAllSites)) {
                    for($i = 0; $i < count($arrStdAllSites); $i++) {
                        $arrListAllSites[$i] = new ResultSite($arrStdAllSites[$i]);
                    }
                } else {
                    $arrListAllSites[0] = new ResultSite($arrStdAllSites);
                }
            }
            return $arrListAllSites;
        } catch (SoapFault $sf) {
            throw new ServerException($sf);
        }
    }

    /**
     * @see EPSInterface::getSiteById()
     */
    public function getSiteById($sessionId, $siteId) {
        try {
            $getSiteByIdStdObject = new stdClass();
            $getSiteByIdStdObject->sessionId = $sessionId;
            $getSiteByIdStdObject->siteId = $siteId;
            $response = parent::getSiteById($getSiteByIdStdObject);
            if (isset($response->return)) {
                $resultSite = new ResultSite($response->return);
            } else {
                $resultSite = null;
            }
            return $resultSite;
        } catch (SoapFault $sf) {
            throw new ServerException($sf);
        }
    }

    /**
     * @see EPSInterface::getSitesByAddrNomenType()
     */
    public function getSitesByAddrNomenType($sessionId, $addrNomen) {
        try {
            $getSitesByAddrNomenTypeStdObject = new stdClass();
            $getSitesByAddrNomenTypeStdObject->sessionId = $sessionId;
            $getSitesByAddrNomenTypeStdObject->addrNomen = $addrNomen;
            $response = parent::getSitesByAddrNomenType($getSitesByAddrNomenTypeStdObject);
            $arrListSitesByAddrNomenType = array();
            if (isset($response->return)) {
                $arrStdSitesByAddrNomenType = $response->return;
                if (is_array($arrStdSitesByAddrNomenType)) {
                    for($i = 0; $i < count($arrStdSitesByAddrNomenType); $i++) {
                        $arrListSitesByAddrNomenType[$i] = new ResultSite($arrStdSitesByAddrNomenType[$i]);
                    }
                } else {
                    $arrListSitesByAddrNomenType[0] = new ResultSite($arrStdSitesByAddrNomenType);
                }
            }
            return $arrListSitesByAddrNomenType;
        } catch (SoapFault $sf) {
            throw new ServerException($sf);
        }
    }

    /**
     * @see EPSInterface::listStreetTypes()
     */
    public function listStreetTypes($sessionId) {
        try {
            $listStreetTypesStdObject = new stdClass();
            $listStreetTypesStdObject->sessionId = $sessionId;
            $response = parent::listStreetTypes($listStreetTypesStdObject);
            $arrListStreetTypes = array();
            if (isset($response->return)) {
                $arrStdListStreetTypes = $response->return;
                if (is_array($arrStdListStreetTypes)) {
                    for($i = 0; $i < count($arrStdListStreetTypes); $i++) {
                        $arrListStreetTypes[$i] = $arrStdListStreetTypes[$i];
                    }
                } else {
                    $arrListStreetTypes[0] = $arrStdListStreetTypes;
                }
            }
            return $arrListStreetTypes;
        } catch (SoapFault $sf) {
            throw new ServerException($sf);
        }
    }

    /**
     * @see EPSInterface::listQuarterTypes()
     */
    public function listQuarterTypes($sessionId) {
        try {
            $listQuarterTypesStdObject = new stdClass();
            $listQuarterTypesStdObject->sessionId = $sessionId;
            $response = parent::listQuarterTypes($listQuarterTypesStdObject);
            $arrListQuarterTypes = array();
            if (isset($response->return)) {
                $arrStdListQuarterTypes = $response->return;
                if (is_array($arrStdListQuarterTypes)) {
                    for($i = 0; $i < count($arrStdListQuarterTypes); $i++) {
                        $arrListQuarterTypes[$i] = $arrStdListQuarterTypes[$i];
                    }
                } else {
                    $arrListQuarterTypes[0] = $arrStdListQuarterTypes;
                }
            }
            return $arrListQuarterTypes;
        } catch (SoapFault $sf) {
            throw new ServerException($sf);
        }
    }

    /**
     * @see EPSInterface::listStreets()
     */
    public function listStreets($sessionId, $name, $siteId) {
        try {
            $listStreetsStdObject = new stdClass();
            $listStreetsStdObject->sessionId = $sessionId;
            $listStreetsStdObject->name      = $name;
            $listStreetsStdObject->siteId    = $siteId;
            $response = parent::listStreets($listStreetsStdObject);
            $arrlistStreets = array();
            if (isset($response->return)) {
                $arrStdListStreets = $response->return;
                if (is_array($arrStdListStreets)) {
                    for($i = 0; $i < count($arrStdListStreets); $i++) {
                        $arrlistStreets[$i] = new ResultStreet($arrStdListStreets[$i]);
                    }
                } else {
                    $arrlistStreets[0] = new ResultStreet($arrStdListStreets);
                }
            }
            return $arrlistStreets;
        } catch (SoapFault $sf) {
            throw new ServerException($sf);
        }
    }

    /**
     * @see EPSInterface::listQuarters()
     */
    public function listQuarters($sessionId, $name, $siteId) {
        try {
            $listQuartersStdObject = new stdClass();
            $listQuartersStdObject->sessionId = $sessionId;
            $listQuartersStdObject->name      = $name;
            $listQuartersStdObject->siteId    = $siteId;
            $response = parent::listQuarters($listQuartersStdObject);
            $arrListQuarters = array();
            if (isset($response->return)) {
                $arrStdListQuarters = $response->return;
                if (is_array($arrStdListQuarters)) {
                    for($i = 0; $i < count($arrStdListQuarters); $i++) {
                        $arrListQuarters[$i] = new ResultQuarter($arrStdListQuarters[$i]);
                    }
                } else {
                    $arrListQuarters[0] = new ResultQuarter($arrStdListQuarters);
                }
            }
            return $arrListQuarters;
        } catch (SoapFault $sf) {
            throw new ServerException($sf);
        }
    }

    /**
     * @see EPSInterface::listCommonObjects()
     */
    public function listCommonObjects($sessionId, $name, $siteId) {
        try {
            $listCommonObjectsStdObject = new stdClass();
            $listCommonObjectsStdObject->sessionId = $sessionId;
            $listCommonObjectsStdObject->name      = $name;
            $listCommonObjectsStdObject->siteId    = $siteId;
            $response = parent::listCommonObjects($listCommonObjectsStdObject);
            $arrListCommonObjects = array();
            if (isset($response->return)) {
                $arrStdListCommonObjects = $response->return;
                if (is_array($arrStdListCommonObjects)) {
                    for($i = 0; $i < count($arrStdListCommonObjects); $i++) {
                        $arrListCommonObjects[$i] = new ResultCommonObject($arrStdListCommonObjects[$i]);
                    }
                } else {
                    $arrListCommonObjects[0] = new ResultCommonObject($arrStdListCommonObjects);
                }
            }
            return $arrListCommonObjects;
        } catch (SoapFault $sf) {
            throw new ServerException($sf);
        }
    }

    /**
     * @see EPSInterface::listBlocks()
     */
    public function listBlocks($sessionId, $name, $siteId) {
        try {
            $listBlocksStdObject = new stdClass();
            $listBlocksStdObject->sessionId = $sessionId;
            $listBlocksStdObject->name      = $name;
            $listBlocksStdObject->siteId    = $siteId;
            $response = parent::listBlocks($listBlocksStdObject);
            $arrListBlocks = array();
            if (isset($response->return)) {
                $arrStdListBlocks = $response->return;
                if (is_array($arrStdListBlocks)) {
                    for($i = 0; $i < count($arrStdListBlocks); $i++) {
                        $arrListBlocks[$i] = $arrStdListBlocks[$i];
                    }
                } else {
                    $arrListBlocks[0] = $arrStdListBlocks;
                }
            }
            return $arrListBlocks;
        } catch (SoapFault $sf) {
            throw new ServerException($sf);
        }
    }

    /**
     * @see EPSInterface::listOffices()
     */
    public function listOffices($sessionId, $name, $siteId) {
        try {
            $listOfficesStdObject = new stdClass();
            $listOfficesStdObject->sessionId = $sessionId;
            $listOfficesStdObject->name      = $name;
            $listOfficesStdObject->siteId    = $siteId;
            $response = parent::listOffices($listOfficesStdObject);
            $arrListOffices = array();
            if (isset($response->return)) {
                $arrStdListOffices = $response->return;
                if (is_array($arrStdListOffices)) {
                    for($i = 0; $i < count($arrStdListOffices); $i++) {
                        $arrListOffices[$i] = new ResultOffice($arrStdListOffices[$i]);
                    }
                } else {
                    $arrListOffices[0] = new ResultOffice($arrStdListOffices);
                }
            }
            return $arrListOffices;
        } catch (SoapFault $sf) {
            throw new ServerException($sf);
        }
    }

    /**
     * @see EPSInterface::getClientById($sessionId, $clientId)
     */
    public function getClientById($sessionId, $clientId) {
        try {
            $getClientByIdStdObject = new stdClass();
            $getClientByIdStdObject->sessionId = $sessionId;
            $getClientByIdStdObject->clientId = $clientId;
            $response = parent::getClientById($getClientByIdStdObject);
            if (isset($response->return)) {
                $resultClientData = new ResultClientData($response->return);
            } else {
                $resultClientData = null;
            }
            return $resultClientData;
        } catch (SoapFault $sf) {
            throw new ServerException($sf);
        }
    }

    /**
     * @see EPSInterface::getAllowedDaysForTaking()
     */
    public function getAllowedDaysForTaking($sessionId, $serviceTypeId, $senderSiteId, $senderOfficeId, $minDate) {
        try {
            $getAllowedDaysForTakingStdObject = new stdClass();
            $getAllowedDaysForTakingStdObject->sessionId      = $sessionId;
            $getAllowedDaysForTakingStdObject->serviceTypeId  = $serviceTypeId;
            $getAllowedDaysForTakingStdObject->senderSiteId   = $senderSiteId;
            $getAllowedDaysForTakingStdObject->senderOfficeId = $senderOfficeId;
            $getAllowedDaysForTakingStdObject->minDate        = $minDate;
            $response = parent::getAllowedDaysForTaking($getAllowedDaysForTakingStdObject);
            $arrGetAllowedDaysForTaking = array();
            if (isset($response->return)) {
                $arrStdGetAllowedDaysForTaking = $response->return;
                if (is_array($arrStdGetAllowedDaysForTaking)) {
                    for($i = 0; $i < count($arrStdGetAllowedDaysForTaking); $i++) {
                        $arrGetAllowedDaysForTaking[$i] = $arrStdGetAllowedDaysForTaking[$i];
                    }
                } else {
                    $arrGetAllowedDaysForTaking[0] = $arrStdGetAllowedDaysForTaking;
                }
            }
            return $arrGetAllowedDaysForTaking;
        } catch (SoapFault $sf) {
            throw new ServerException($sf);
        }
    }

    /**
     * @see EPSInterface::addressSearch()
     */
    public function addressSearch($sessionId, $address) {
        try {
            $addressSearchStdObject = new stdClass();
            $addressSearchStdObject->sessionId = $sessionId;
            $addressSearchStdObject->address   = $address->toStdClass();
            $response = parent::addressSearch($addressSearchStdObject);
            $arrAddressSearch = array();
            if (isset($response->return)) {
                $arrStdAddressSearch = $response->return;
                if (is_array($arrStdAddressSearch)) {
                    for($i = 0; $i < count($arrStdAddressSearch); $i++) {
                        $arrAddressSearch[$i] = new ResultAddressSearch($arrStdAddressSearch[$i]);
                    }
                } else {
                    $arrAddressSearch[0] = new ResultAddressSearch($arrStdAddressSearch);
                }
            }
            return $arrAddressSearch;
        } catch (SoapFault $sf) {
            throw new ServerException($sf);
        }
    }

    /**
     * @see EPSInterface::calculate()
     */
    public function calculate($sessionId, $calculation) {
        try {
            $calculateStdObject = new stdClass();
            $calculateStdObject->sessionId   = $sessionId;
            $calculateStdObject->calculation = $calculation->toStdClass();
            $response = parent::calculate($calculateStdObject);
            if (isset($response->return)) {
                $resultCalculation = new ResultCalculation($response->return);
            } else {
                $resultCalculation = null;
            }
            return $resultCalculation;
        } catch (SoapFault $sf) {
            throw new ServerException($sf);
        }
    }

    /**
     * @see EPSInterface::calculateMultipleServices()
     */
    public function calculateMultipleServices($sessionId, $calculation, $serviceTypeIds) {
        try {
            $calculateMultipleServicesStdObject = new stdClass();
            $calculateMultipleServicesStdObject->sessionId      = $sessionId;
            $calculateMultipleServicesStdObject->calculation    = $calculation->toStdClass();
            $calculateMultipleServicesStdObject->serviceTypeIds = $serviceTypeIds;
            $calculateMultipleServicesStdObject->calculation->serviceTypeId = ParamCalculation::CALCULATE_MULTUPLE_SERVICES_SERVICE_TYPE_ID;
            $response = parent::calculateMultipleServices($calculateMultipleServicesStdObject);
            $arrCalculateMultipleServices = array();
            if (isset($response->return)) {
                $arrStdCalculateMultipleServices = $response->return;
                if (is_array($arrStdCalculateMultipleServices)) {
                    for($i = 0; $i < count($arrStdCalculateMultipleServices); $i++) {
                        $arrCalculateMultipleServices[$i] = new ResultCalculationMS($arrStdCalculateMultipleServices[$i]);
                    }
                } else {
                    $arrCalculateMultipleServices[0] = new ResultCalculationMS($arrStdCalculateMultipleServices);
                }
            }
            return $arrCalculateMultipleServices;
        } catch (SoapFault $sf) {
            throw new ServerException($sf);
        }
    }

    /**
     * @see EPSInterface::calculatePicking()
     */
    public function calculatePicking($sessionId, $picking) {
        try {
            $calculatePickingStdObject = new stdClass();
            $calculatePickingStdObject->sessionId = $sessionId;
            $calculatePickingStdObject->picking   = $picking->toStdClass();
            $response = parent::calculatePicking($calculatePickingStdObject);
            if (isset($response->return)) {
                $resultCalculation = new ResultCalculation($response->return);
            } else {
                $resultCalculation = null;
            }
            return $resultCalculation;
        } catch (SoapFault $sf) {
            throw new ServerException($sf);
        }
    }

    /**
     * @see EPSInterface::createBillOfLading()
     */
    public function createBillOfLading($sessionId, $picking) {
        try {
            $createBillOfLadingStdObject = new stdClass();
            $createBillOfLadingStdObject->sessionId = $sessionId;
            $createBillOfLadingStdObject->picking   = $picking->toStdClass();
            $response = parent::createBillOfLading($createBillOfLadingStdObject);
            if (isset($response->return)) {
                $resultBOL = new ResultBOL($response->return);
            } else {
                $resultBOL = null;
            }
            return $resultBOL;
        } catch (SoapFault $sf) {
            throw new ServerException($sf);
        }
    }

    /**
     * @see EPSInterface::createPDF()
     */
    public function createPDF($sessionId, $params) {
        try {
            $createPDFStdObject = new stdClass();
            $createPDFStdObject->sessionId = $sessionId;
            $createPDFStdObject->params    = $params->toStdClass();
            $response = parent::createPDF($createPDFStdObject);
            if (isset($response->return)) {
                $resultPDF = $response->return;
            } else {
                $resultPDF = null;
            }
            return $resultPDF;
        } catch (SoapFault $sf) {
            throw new ServerException($sf);
        }
    }

    /**
     * @see EPSInterface::createBillOfLadingPDF()
     */
    public function createBillOfLadingPDF($sessionId, $billOfLading, $includeAutoPrintJS) {
        try {
            $createBillOfLadingPDFStdObject = new stdClass();
            $createBillOfLadingPDFStdObject->sessionId          = $sessionId;
            $createBillOfLadingPDFStdObject->billOfLading       = $billOfLading;
            $createBillOfLadingPDFStdObject->includeAutoPrintJS = $includeAutoPrintJS;
            $response = parent::createBillOfLadingPDF($createBillOfLadingPDFStdObject);
            if (isset($response->return)) {
                $resultPDF = $response->return;
            } else {
                $resultPDF = null;
            }
            return $resultPDF;
        } catch (SoapFault $sf) {
            throw new ServerException($sf);
        }
    }

    /**
     * @see EPSInterface::createCustomTravelLabelPDFType1()
     */
    public function createCustomTravelLabelPDFType1($sessionId, $parcelId) {
        try {
            $createCustomTravelLabelPDFType1StdObject = new stdClass();
            $createCustomTravelLabelPDFType1StdObject->sessionId = $sessionId;
            $createCustomTravelLabelPDFType1StdObject->parcelId  = $parcelId;
            $response = parent::createCustomTravelLabelPDFType1($createCustomTravelLabelPDFType1StdObject);
            if (isset($response->return)) {
                $resultPDF = $response->return;
            } else {
                $resultPDF = null;
            }
            return $resultPDF;
        } catch (SoapFault $sf) {
            throw new ServerException($sf);
        }
    }

    /**
     * @see EPSInterface::invalidatePicking()
     */
    public function invalidatePicking($sessionId, $billOfLading) {
        try {
            $invalidatePickingStdObject = new stdClass();
            $invalidatePickingStdObject->sessionId    = $sessionId;
            $invalidatePickingStdObject->billOfLading = $billOfLading;
            parent::invalidatePicking($invalidatePickingStdObject);
        } catch (SoapFault $sf) {
            throw new ServerException($sf);
        }
    }

    /**
     * @see EPSInterface::updateBillOfLading()
     */
    public function updateBillOfLading($sessionId, $picking) {
        try {
            $updateBillOfLadingStdObject = new stdClass();
            $updateBillOfLadingStdObject->sessionId = $sessionId;
            $updateBillOfLadingStdObject->picking   = $picking->toStdClass();
            $response = parent::updateBillOfLading($updateBillOfLadingStdObject);
            if (isset($response->return)) {
                $resultBOL = new ResultBOL($response->return);
            } else {
                $resultBOL = null;
            }
            return $resultBOL;
        } catch (SoapFault $sf) {
            throw new ServerException($sf);
        }
    }

    /**
     * @see EPSInterface::addParcel()
     */
    public function addParcel($sessionId, $parcel) {
        try {
            $addParcelStdObject = new stdClass();
            $addParcelStdObject->sessionId = $sessionId;
            $addParcelStdObject->parcel    = $parcel->toStdClass();
            $response = parent::addParcel($addParcelStdObject);
            if (isset($response->return)) {
                $result = $response->return;
            } else {
                $result = null;
            }
            return $result;
        } catch (SoapFault $sf) {
            throw new ServerException($sf);
        }
    }

    /**
     * @see EPSInterface::finalizeBillOfLadingCreation()
     */
    public function finalizeBillOfLadingCreation($sessionId, $billOfLading) {
        try {
            $finalizeBillOfLadingCreationStdObject = new stdClass();
            $finalizeBillOfLadingCreationStdObject->sessionId    = $sessionId;
            $finalizeBillOfLadingCreationStdObject->billOfLading = $billOfLading;
            $response = parent::finalizeBillOfLadingCreation($finalizeBillOfLadingCreationStdObject);
            if (isset($response->return)) {
                $resultBOL = new ResultBOL($response->return);
            } else {
                $resultBOL = null;
            }
            return $resultBOL;
        } catch (SoapFault $sf) {
            throw new ServerException($sf);
        }
    }

    /**
     * @see EPSInterface::createOrder()
     */
    public function createOrder($sessionId, $order) {
        try {
            $createOrderStdObject = new stdClass();
            $createOrderStdObject->sessionId = $sessionId;
            $createOrderStdObject->order     = $order->toStdClass();
            $response = parent::createOrder($createOrderStdObject);
            $arrCreateOrder = array();
            if (isset($response->return)) {
                $arrStdCreateOrder = $response->return;
                if (is_array($arrStdCreateOrder)) {
                    for($i = 0; $i < count($arrStdCreateOrder); $i++) {
                        $arrCreateOrder[$i] = new ResultOrderPickingInfo($arrStdCreateOrder[$i]);
                    }
                } else {
                    $arrCreateOrder[0] = new ResultOrderPickingInfo($arrStdCreateOrder);
                }
            }
            return $arrCreateOrder;
        } catch (SoapFault $sf) {
            throw new ServerException($sf);
        }
    }

    /**
     * @see EPSInterface::getPickingParcels()
     */
    public function getPickingParcels($sessionId, $billOfLading) {
        try {
            $getPickingParcelsStdObject = new stdClass();
            $getPickingParcelsStdObject->sessionId    = $sessionId;
            $getPickingParcelsStdObject->billOfLading = $billOfLading;
            $response = parent::getPickingParcels($getPickingParcelsStdObject);
            $arrResultParcelInfo = array();
            if (isset($response->return)) {
                $arrStdResultParcelInfo = $response->return;
                if (is_array($arrStdResultParcelInfo)) {
                    for($i = 0; $i < count($arrStdResultParcelInfo); $i++) {
                        $arrResultParcelInfo[$i] = new ResultParcelInfo($arrStdResultParcelInfo[$i]);
                    }
                } else {
                    $arrResultParcelInfo[0] = new ResultParcelInfo($arrStdResultParcelInfo);
                }
            }
            return $arrResultParcelInfo;
        } catch (SoapFault $sf) {
            throw new ServerException($sf);
        }
    }

    /**
     * @see EPSInterface::trackPicking()
     */
    public function trackPicking($sessionId, $billOfLading) {
        try {
            $trackPickingStdObject = new stdClass();
            $trackPickingStdObject->sessionId    = $sessionId;
            $trackPickingStdObject->billOfLading = $billOfLading;
            $response = parent::trackPicking($trackPickingStdObject);
            $arrResultTrackPicking = array();
            if (isset($response->return)) {
                $arrStdResultTrackPicking = $response->return;
                if (is_array($arrStdResultTrackPicking)) {
                    for($i = 0; $i < count($arrStdResultTrackPicking); $i++) {
                        $arrResultTrackPicking[$i] = new ResultTrackPicking($arrStdResultTrackPicking[$i]);
                    }
                } else {
                    $arrResultTrackPicking[0] = new ResultTrackPicking($arrStdResultTrackPicking);
                }
            }
            return $arrResultTrackPicking;
        } catch (SoapFault $sf) {
            throw new ServerException($sf);
        }
    }

    /**
     * @see EPSInterface::trackPickingEx()
     */
    public function trackPickingEx($sessionId, $billOfLading, $language) {
        try {
            $trackPickingExStdObject = new stdClass();
            $trackPickingExStdObject->sessionId    = $sessionId;
            $trackPickingExStdObject->billOfLading = $billOfLading;
            $trackPickingExStdObject->language     = $language;
            $response = parent::trackPickingEx($trackPickingExStdObject);
            $arrResultTrackPickingEx = array();

            if (isset($response->return)) {
                $arrStdResultTrackPickingEx = $response->return;
                if (is_array($arrStdResultTrackPickingEx)) {
                    for($i = 0; $i < count($arrStdResultTrackPickingEx); $i++) {
                        $arrResultTrackPickingEx[$i] = new ResultTrackPickingEx($arrStdResultTrackPickingEx[$i]);
                    }
                } else {
                    $arrResultTrackPickingEx[0] = new ResultTrackPickingEx($arrStdResultTrackPickingEx);
                }
            }
            return $arrResultTrackPickingEx;
        } catch (SoapFault $sf) {
            throw new ServerException($sf);
        }
    }

    /**
     * @see EPSInterface::searchPickingsByRefNumber()
     */
    public function searchPickingsByRefNumber($sessionId, $params) {
        try {
            $searchPickingsByRefNumberStdObject = new stdClass();
            $searchPickingsByRefNumberStdObject->sessionId = $sessionId;
            $searchPickingsByRefNumberStdObject->params    = $params->toStdClass();
            $response = parent::searchPickingsByRefNumber($searchPickingsByRefNumberStdObject);
            $arrSearchPickingsByRefNumber = array();
            if (isset($response->return)) {
                $arrStdSearchPickingsByRefNumber = $response->return;
                if (is_array($arrStdSearchPickingsByRefNumber)) {
                    for($i = 0; $i < count($arrStdSearchPickingsByRefNumber); $i++) {
                        $arrSearchPickingsByRefNumber[$i] = $arrStdSearchPickingsByRefNumber[$i];
                    }
                } else {
                    $arrSearchPickingsByRefNumber[0] = $arrStdSearchPickingsByRefNumber;
                }
            }
            return $arrSearchPickingsByRefNumber;
        } catch (SoapFault $sf) {
            throw new ServerException($sf);
        }
    }
    
    /**
     * @see EPSInterface::trackParcel()
     */
    public function trackParcel($sessionId, $parcelId, $language) {
        try {
            $trackParcelStdObject = new stdClass();
            $trackParcelStdObject->sessionId = $sessionId;
            $trackParcelStdObject->parcelId  = $parcelId;
            $trackParcelStdObject->language  = $language;
            $response = parent::trackParcel($trackParcelStdObject);
            $arrResultTrackParcel = array();
    
            if (isset($response->return)) {
                $arrStdResultTrackParcel = $response->return;
                if (is_array($arrStdResultTrackParcel)) {
                    for($i = 0; $i < count($arrStdResultTrackParcel); $i++) {
                        $arrResultTrackParcel[$i] = new ResultTrackPickingEx($arrStdResultTrackParcel[$i]);
                    }
                } else {
                    $arrResultTrackParcel[0] = new ResultTrackPickingEx($arrStdResultTrackParcel);
                }
            }
            return $arrResultTrackParcel;
        } catch (SoapFault $sf) {
            throw new ServerException($sf);
        }
    }
    
    /**
     * @see EPSInterface::getMicroregionId
     */
    public function getMicroregionId($sessionId, $coordX, $coordY) {
        try {
            $getMicroregionIdSdtClass = new stdClass();
            $getMicroregionIdSdtClass->sessionId = $sessionId;
            $getMicroregionIdSdtClass->coordX    = $coordX;
            $getMicroregionIdSdtClass->coordY    = $coordY;
            $response = parent::getMicroregionId($getMicroregionIdSdtClass);
            if (isset($response->return)) {
                $microregionId = $response->return;
            } else {
                $microregionId = null;
            }
            return $microregionId;
        } catch (SoapFault $sf) {
            throw new ServerException($sf);
        }
    }
    
    /**
     * @see EPSInterface::searchClients()
     */
    public function searchClients($sessionId, $clientQuery) {
        try {
            $searchClientsStdObject = new stdClass();
            $searchClientsStdObject->sessionId   = $sessionId;
            $searchClientsStdObject->clientQuery = $clientQuery->toStdClass();
            $response = parent::searchClients($searchClientsStdObject);
            $arrResultClientData = array();
        
            if (isset($response->return)) {
                $arrStdResultClientData = $response->return;
                if (is_array($arrStdResultClientData)) {
                    for($i = 0; $i < count($arrStdResultClientData); $i++) {
                        $arrResultClientData[$i] = new ResultClientData($arrStdResultClientData[$i]);
                    }
                } else {
                    $arrResultClientData[0] = new ResultClientData($arrStdResultClientData);
                }
            }
            return $arrResultClientData;
        } catch (SoapFault $sf) {
            throw new ServerException($sf);
        }
    }
    
    /**
     * @see EPSInterface::listSpecialDeliveryRequirements()
     */
    public function listSpecialDeliveryRequirements($sessionId) {
    	try {    
    		$listSpecialDeliveryRequirementsStdObject = new stdClass();
            $listSpecialDeliveryRequirementsStdObject->sessionId = $sessionId;
            $response = parent::listSpecialDeliveryRequirements($listSpecialDeliveryRequirementsStdObject);
            $arrResultSpecialDeliveryRequirement = array();
        
            if (isset($response->return)) {
                $arrStdResultSpecialDeliveryRequirement = $response->return;
                if (is_array($arrStdResultSpecialDeliveryRequirement)) {
                    for($i = 0; $i < count($arrStdResultSpecialDeliveryRequirement); $i++) {
                        $arrResultSpecialDeliveryRequirement[$i] = new ResultSpecialDeliveryRequirement($arrStdResultSpecialDeliveryRequirement[$i]);
                    }
                } else {
                    $arrResultSpecialDeliveryRequirement[0] = new ResultSpecialDeliveryRequirement($arrStdResultSpecialDeliveryRequirement);
                }
            }
            return $arrResultSpecialDeliveryRequirement;
        } catch (SoapFault $sf) {
            throw new ServerException($sf);
        }
       }
       
       /**
        * @see EPSInterface::validateAddress()
        */
       public function validateAddress($sessionId, $address, $validationMode) {
       	try {
       		$validateAddressStdObject = new stdClass();
       		$validateAddressStdObject->sessionId = $sessionId;
       		$validateAddressStdObject->address   = $address->toStdClass();
       		$validateAddressStdObject->validationMode = $validationMode;
       		$response = parent::validateAddress($validateAddressStdObject);
            return $response->return;
       	} catch (SoapFault $sf) {
       		throw new ServerException($sf);
       	}
       }
       
       /**
        * @see EPSInterface::listContractClients()
        */
       public function listContractClients($sessionId) {
       	try {
       		$listContractClientsStdObject = new stdClass();
       		$listContractClientsStdObject->sessionId = $sessionId;
       		$response = parent::listContractClients($listContractClientsStdObject);
       		$arrResultContractClients = array();
       
       		if (isset($response->return)) {
       			$arrStdResultContractClients = $response->return;
       			if (is_array($arrStdResultContractClients)) {
       				for($i = 0; $i < count($arrStdResultContractClients); $i++) {
       					$arrResultContractClients[$i] = new ResultClientData($arrStdResultContractClients[$i]);
       				}
       			} else {
       				$arrResultContractClients[0] = new ResultClientData($arrStdResultContractClients);
       			}
       		}
       		return $arrResultContractClients;
       	} catch (SoapFault $sf) {
       		throw new ServerException($sf);
       	}
       }
       
       /**
        * @see EPSInterface::listOfficesEx()
        */
       public function listOfficesEx($sessionId, $name, $siteId) {
       	try {
       		$listOfficesExStdObject = new stdClass();
       		$listOfficesExStdObject->sessionId = $sessionId;
       		$listOfficesExStdObject->name      = $name;
       		$listOfficesExStdObject->siteId    = $siteId;
       		$response = parent::listOfficesEx($listOfficesExStdObject);
       		$arrListOfficesEx = array();
       		if (isset($response->return)) {
       			$arrStdListOfficesEx = $response->return;
       			if (is_array($arrStdListOfficesEx)) {
       				for($i = 0; $i < count($arrStdListOfficesEx); $i++) {
       					$arrListOfficesEx[$i] = new ResultOfficeEx($arrStdListOfficesEx[$i]);
       				}
       			} else {
       				$arrListOfficesEx[0] = new ResultOfficeEx($arrStdListOfficesEx);
       			}
       		}
       		return $arrListOfficesEx;
       	} catch (SoapFault $sf) {
       		throw new ServerException($sf);
       	}
       }
}
?>