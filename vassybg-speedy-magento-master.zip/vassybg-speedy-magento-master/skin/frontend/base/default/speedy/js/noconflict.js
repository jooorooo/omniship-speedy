var $j=jQuery.noConflict();
